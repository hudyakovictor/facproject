"""Official 3DDFA-V3 MobileNet checkpoint and basis, CPU-only inference.
The network and 3DMM equations match vendor/model/recon.py. No fake mesh fallback.
The lightweight YuNet detector supplies five landmarks; POS alignment follows upstream.
"""

import sys, time, threading
from pathlib import Path
import numpy as np
import cv2
from PIL import Image, ImageOps
from scipy.io import loadmat
from server.config import ROOT, ASSETS, CONFIG, digest, read_yaml

VERSION = "3ddfa-v3-mbnet-e153858-pos-yunet-v3-exif"
MODEL_HASH = "435f33e6fc93f3c0857538ffc5024d29bd6d09f98391d9be55f2d32b23cc2604"
_lock = threading.RLock()
_instance = None


def availability():
    needed = [
        "face_model.npy",
        "net_recon_mbnet.pth",
        "similarity_Lm3D_all.mat",
        "face_detection_yunet_2023mar.onnx",
    ]
    missing = [f for f in needed if not (ASSETS / f).exists()]
    return {
        "id": "3ddfa_v3",
        "title": "3DDFA_V3",
        "available": not missing,
        "backbone": "MobileNet-V3",
        "device": "CPU",
        "version": VERSION,
        "reason": ("Нет ассетов: " + ", ".join(missing)) if missing else None,
    }


def get_model():
    global _instance
    with _lock:
        if _instance is None:
            _instance = TDDFA()
    return _instance


class TDDFA:
    def __init__(self):
        if not availability()["available"]:
            raise RuntimeError(availability()["reason"])
        import torch

        self.torch = torch
        torch.set_num_threads(2)
        torch.manual_seed(42)
        path = str(ROOT / "vendor/3DDFA-V3")
        if path not in sys.path:
            sys.path.insert(0, path)
        from model.networks import define_net_recon_mobilenetv3

        self.net = define_net_recon_mobilenetv3("recon_mobilenetv3_large", False, None)
        state = torch.load(
            ASSETS / "net_recon_mbnet.pth", map_location="cpu", weights_only=True
        )
        self.net.load_state_dict(state["net_recon"])
        self.net.eval()
        self.basis = np.load(ASSETS / "face_model.npy", allow_pickle=True).item()
        self.mean = self.basis["u"].reshape(-1, 3).astype(np.float32)
        self.tri = np.asarray(self.basis["tri"], np.int32)
        self.ldm = {
            k: np.asarray(self.basis[k], np.int32).reshape(-1)
            for k in ["ldm68", "ldm106", "ldm134"]
        }
        lm = self.mean[self.ldm["ldm68"]]
        self.origin = (lm[36:42].mean(0) + lm[42:48].mean(0)) / 2
        self.scale = float(np.linalg.norm(lm[36:42].mean(0) - lm[42:48].mean(0)))
        std = loadmat(ASSETS / "similarity_Lm3D_all.mat")["lm"]
        ix = np.array([31, 37, 40, 43, 46, 49, 55]) - 1
        self.lm3d = np.stack(
            [
                std[ix[0]],
                std[ix[[1, 2]]].mean(0),
                std[ix[[3, 4]]].mean(0),
                std[ix[5]],
                std[ix[6]],
            ]
        )[[1, 2, 0, 3, 4]]
        self.detector = cv2.FaceDetectorYN.create(
            str(ASSETS / "face_detection_yunet_2023mar.onnx"),
            "",
            (320, 320),
            0.7,
            0.3,
            5000,
        )

    def align(self, image, precropped=False):
        rgb = np.asarray(image.convert("RGB"))
        if precropped:
            return image.convert("RGB").resize((224, 224)), {
                "mode": "manual_precropped",
                "confidence": None,
            }
        h, w = rgb.shape[:2]
        factor = min(1.0, 800 / max(h, w))
        dw, dh = int(w * factor), int(h * factor)
        im = cv2.resize(rgb, (dw, dh))
        self.detector.setInputSize((dw, dh))
        _, faces = self.detector.detect(cv2.cvtColor(im, cv2.COLOR_RGB2BGR))
        if faces is None or len(faces) == 0:
            raise ValueError(
                "Лицо не найдено. Для уже выровненного портрета включите «Готовый кроп 224×224». Профиль может требовать ручного кропа."
            )
        face = max(faces, key=lambda x: x[2] * x[3])
        points = face[4:14].reshape(5, 2).astype(float) / factor
        # Standard 3D landmarks are ordered image-left eye, image-right eye, nose, mouth-left, mouth-right.
        points = np.concatenate(
            [
                points[:2][np.argsort(points[:2, 0])],
                points[2:3],
                points[3:][np.argsort(points[3:, 0])],
            ]
        )
        points[:, 1] = h - 1 - points[:, 1]
        n = 5
        A = np.zeros((n * 2, 8))
        A[0::2, :3] = self.lm3d
        A[0::2, 3] = 1
        A[1::2, 4:7] = self.lm3d
        A[1::2, 7] = 1
        k = np.linalg.lstsq(A, points.reshape(-1, 1), rcond=None)[0]
        s = (np.linalg.norm(k[:3]) + np.linalg.norm(k[4:7])) / 2
        s = float(102.0 / s)
        tx, ty = float(k[3, 0]), float(k[7, 0])
        nw, nh = int(w * s), int(h * s)
        if nw > 12000 or nh > 12000:
            raise ValueError("Лицо слишком мало: загрузите более крупный кроп")
        left = int(nw / 2 - 112 + (tx - w / 2) * s)
        top = int(nh / 2 - 112 + (h / 2 - ty) * s)
        aligned = (
            image.convert("RGB")
            .resize((nw, nh), Image.Resampling.BICUBIC)
            .crop((left, top, left + 224, top + 224))
        )
        return aligned, {
            "mode": "yunet_pos5",
            "confidence": float(face[-1]),
            "detected_faces": len(faces),
            "bbox": (face[:4] / factor).tolist(),
            "crop": [left, top, s],
        }

    def reconstruct(self, alpha):
        a = np.asarray(alpha, np.float32).reshape(-1)
        shape = (
            self.basis["u"].reshape(-1)
            + self.basis["id"] @ a[:80]
            + self.basis["exp"] @ a[80:144]
        ).reshape(-1, 3)
        identity = (self.basis["u"].reshape(-1) + self.basis["id"] @ a[:80]).reshape(
            -1, 3
        )
        albedo = np.clip(
            (self.basis["u_alb"].reshape(-1) + self.basis["alb"] @ a[144:224]).reshape(
                -1, 3
            )
            / 255.0,
            0,
            1,
        )
        return {
            "vertices": ((shape - self.origin) / self.scale).astype(np.float32),
            "identity": ((identity - self.origin) / self.scale).astype(np.float32),
            "albedo": albedo.astype(np.float32),
        }

    def infer(self, path, precropped=False):
        start = time.perf_counter()
        with _lock:
            runtime = read_yaml(CONFIG / "runtime.yaml")
            self.torch.set_num_threads(int(runtime.get("torch_threads", 2)))
            self.detector.setScoreThreshold(
                float(runtime.get("detector_confidence", 0.7))
            )
            image = ImageOps.exif_transpose(Image.open(path)).convert("RGB")
            image.load()
            aligned, alignment = self.align(image, precropped)
            x = np.array(aligned, dtype=np.float32) / 255.0
            t = self.torch.from_numpy(x.transpose(2, 0, 1).copy()).unsqueeze(0)
            with self.torch.inference_mode():
                alpha = self.net(t).numpy()[0].copy()
            result = self.reconstruct(alpha)
        angles = {
            "yaw": float(np.degrees(alpha[225])),
            "pitch": float(np.degrees(alpha[224])),
            "roll": float(np.degrees(alpha[226])),
        }
        gray = cv2.cvtColor(np.array(image.convert("RGB")), cv2.COLOR_RGB2GRAY)
        meta = {
            "model": VERSION,
            "weights_sha256": MODEL_HASH,
            "seed": 42,
            "angles": angles,
            "alignment": alignment,
            "seconds": round(time.perf_counter() - start, 3),
            "sharpness": float(cv2.Laplacian(gray, cv2.CV_64F).var()),
            "units": "fixed_template_IOD",
            "runtime": runtime,
            "warning": "Реконструкция — оценка модели, не физическое измерение и не доказательство изменения личности.",
        }
        result["alpha"] = alpha
        return result, meta, aligned

    def topology(self):
        return {
            "triangles": self.tri.tolist(),
            "landmarks": {k: v.tolist() for k, v in self.ldm.items()},
            "mean": ((self.mean - self.origin) / self.scale).round(6).tolist(),
            "vertex_count": len(self.mean),
            "triangle_count": len(self.tri),
            "units": "template IOD",
            "version": VERSION,
        }
