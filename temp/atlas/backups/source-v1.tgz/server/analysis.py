import json, time
import numpy as np
from server import registry, storage
from server.config import ROOT, CONFIG, digest, atomic_json


def metrics_table():
    import inspect

    cat = registry.catalog()
    ov = registry.overrides()
    rows = []
    ready = [p for p in storage.library() if p["status"] == "ready"]
    lm = next(
        (
            ROOT / "data/topology.json"
            for _ in [0]
            if (ROOT / "data/topology.json").exists()
        ),
        None,
    )
    if lm is not None:
        landmarks = json.loads(lm.read_text())["landmarks"]
    else:
        from server.models.tddfa import get_model

        landmarks = {k: v.tolist() for k, v in get_model().ldm.items()} if ready else {}
    for p in ready:
        raw = storage.photo(p["id"])
        cachepath = ROOT / "cache" / p["id"] / "metrics.json"
        saved = json.loads(cachepath.read_text()) if cachepath.exists() else {}
        result = {}
        ctx = None
        for d in registry.definitions():
            conf = ov.get((d.model, p["pose"], d.id), {})
            key = digest(
                {
                    "feature": storage.key_for(raw),
                    "pose": p["pose"],
                    "config": conf,
                    "fn": inspect.getsource(d.fn),
                    "common": (ROOT / "metrics/common.py").read_text(),
                }
            )
            if d.id in saved and saved[d.id]["key"] == key:
                result[d.id] = saved[d.id]["result"]
                continue
            if (
                p["pose"] == "unclassified"
                or not conf.get("enabled", True)
                or (d.poses and p["pose"] not in d.poses)
            ):
                item = {
                    "value": None,
                    "reason": "Ракурс вне профилей или метрика выключена",
                }
            elif d.model != "3ddfa_v3":
                item = {"value": None, "reason": "Модель ещё не установлена"}
            else:
                if ctx is None:
                    f = storage.load_features(raw)
                    ctx = {**f, **{k: f["vertices"][v] for k, v in landmarks.items()}}
                try:
                    v = float(d.fn(ctx))
                    item = {
                        "value": v if np.isfinite(v) else None,
                        "reason": None if np.isfinite(v) else "Не определено",
                    }
                except Exception as e:
                    item = {"value": None, "reason": str(e)}
            saved[d.id] = {"key": key, "result": item}
            result[d.id] = dict(item)
        atomic_json(cachepath, saved)
        rows.append(
            {
                "id": p["id"],
                "group": p["group"],
                "date": p["date"],
                "pose": p["pose"],
                "metrics": result,
                "sharpness": p["meta"]["sharpness"],
            }
        )
    return {
        "catalog": cat,
        "rows": registry.robust_scores(rows),
        "config_version": registry.version(),
    }


def project(job, params):
    from sklearn.decomposition import PCA
    from sklearn.manifold import TSNE
    from sklearn.cluster import KMeans
    from sklearn.metrics import pairwise_distances, silhouette_score
    from sklearn.preprocessing import normalize

    ps = [
        storage.photo(id)
        for id in params["photo_ids"]
        if storage.feature_path(storage.photo(id)).exists()
    ]
    if len(ps) < 2:
        raise ValueError("Для проекции нужны хотя бы 2 обработанных фото")
    n = len(ps)
    seed = int(params.get("seed", 42))
    dim = int(params.get("dimensions", 2))
    method = params.get("method", "pca")
    distance = params.get("distance", "cosine")
    cachekey = digest({"params": params, "features": [storage.key_for(p) for p in ps]})
    path = ROOT / "cache/projections" / f"{cachekey}.json"
    if path.exists():
        return json.loads(path.read_text()) | {"cache_hit": True}
    job.update(0.05, "Загрузка α_id")
    x = np.array([storage.load_features(p, ["alpha"])["alpha"][:80] for p in ps])
    used = method
    note = None
    if method == "umap" and n < 6:
        used = "pca"
        note = "Для UMAP нужно не менее 6 фото. Показан PCA."
    if used == "pca":
        k = min(dim, n, x.shape[1])
        pca = PCA(n_components=k, random_state=seed)
        coords = pca.fit_transform(x)
        explained = float(pca.explained_variance_ratio_.sum())
    elif used == "tsne":
        perplexity = min(float(params.get("perplexity", 15)), n - 1)
        coords = TSNE(
            n_components=dim,
            perplexity=perplexity,
            metric=distance,
            random_state=seed,
            init="pca",
            learning_rate="auto",
            max_iter=750,
        ).fit_transform(x)
        explained = None
    elif used == "umap":
        job.update(0.15, "UMAP · первый запуск может компилировать numba")
        import umap

        coords = umap.UMAP(
            n_components=dim,
            n_neighbors=min(int(params.get("n_neighbors", 15)), n - 1),
            min_dist=float(params.get("min_dist", 0.1)),
            metric=distance,
            random_state=seed,
            n_jobs=1,
        ).fit_transform(x)
        explained = None
    else:
        raise ValueError("Неизвестный метод проекции")
    if coords.shape[1] < dim:
        coords = np.pad(coords, ((0, 0), (0, dim - coords.shape[1])))
    job.update(0.75, "Расстояния и статистика")
    matrix = pairwise_distances(x, metric=distance)
    groups = [p["group"] for p in ps]
    unique = sorted(set(groups))
    centroids = np.array([x[np.array(groups) == g].mean(0) for g in unique])
    dispersion = {
        g: float(
            np.mean(np.sum((x[np.array(groups) == g] - centroids[i]) ** 2, axis=1))
        )
        for i, g in enumerate(unique)
    }
    sil = (
        float(silhouette_score(x, groups, metric=distance))
        if 1 < len(unique) < n
        else None
    )
    count = min(max(1, int(params.get("clusters", 3))), n)
    labels = KMeans(n_clusters=count, random_state=seed, n_init=10).fit_predict(
        normalize(x) if distance == "cosine" else x
    )
    result = {
        "points": [
            {
                "id": p["id"],
                "group": p["group"],
                "coords": coords[i].tolist(),
                "norm": float(np.linalg.norm(x[i])),
                "cluster": int(labels[i]),
            }
            for i, p in enumerate(ps)
        ],
        "matrix": matrix.round(5).tolist(),
        "groups": unique,
        "centroid_distances": pairwise_distances(centroids, metric=distance)
        .round(5)
        .tolist(),
        "dispersion": dispersion,
        "silhouette": sil,
        "explained_variance": explained,
        "method": used,
        "requested_method": method,
        "note": note,
        "seed": seed,
        "params": params,
        "cache_key": cachekey,
        "cache_hit": False,
        "note_embedding": "α_id — параметры 3DMM, не AdaFace и не достоверность личности.",
    }
    atomic_json(path, result)
    return result
