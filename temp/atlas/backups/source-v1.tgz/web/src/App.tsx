import { useEffect, useRef, useState, useCallback } from "react";
import {
  ReactFlow,
  ReactFlowProvider,
  Background,
  BackgroundVariant,
  MiniMap,
  Controls,
  useReactFlow,
  type Connection,
  type Edge,
  Panel,
} from "@xyflow/react";
import {
  Plus,
  ChevronDown,
  Check,
  Cpu,
  Compass,
  Activity,
  Shapes,
  Maximize,
  MousePointer2,
  HelpCircle,
  Undo2,
  Focus,
  ScatterChart,
  Box,
  Images,
  X,
  LoaderCircle,
  AlertCircle,
  Lock,
} from "lucide-react";
import { useStore, initialNodes, initialEdges, type WorkNode } from "./store";
import { api, post } from "./api";
import {
  SourceNode,
  ProcessorNode,
  MetricProcessorNode,
  PendingNode,
} from "./components/DataNodes";
import { SceneNode } from "./components/SceneNode";
import { ClusterNode } from "./components/ClusterNode";
import { PoseNode, RegistryNode } from "./components/ConfigNodes";
import { PhotoEditor } from "./components/PhotoEditor";
import { usePlayback } from "./components/Timeline";
import "@xyflow/react/dist/style.css";
import "./styles.css";
const nodeTypes = {
  source: SourceNode,
  processor: ProcessorNode,
  metricProcessor: MetricProcessorNode,
  scene: SceneNode,
  cluster: ClusterNode,
  poses: PoseNode,
  registry: RegistryNode,
  pending: PendingNode,
};
function Workbench() {
  const nodes = useStore((s) => s.nodes),
    edges = useStore((s) => s.edges),
    onNodesChange = useStore((s) => s.onNodesChange),
    onEdgesChange = useStore((s) => s.onEdgesChange),
    onConnect = useStore((s) => s.onConnect),
    loaded = useStore((s) => s.loaded),
    photos = useStore((s) => s.photos),
    models = useStore((s) => s.models),
    jobs = useStore((s) => s.jobs),
    error = useStore((s) => s.error),
    toast = useStore((s) => s.toast),
    group = useStore((s) => s.group),
    activeId = useStore((s) => s.activeId),
    route = useStore((s) => s.route),
    heat = useStore((s) => s.heat),
    visibleMetrics = useStore((s) => s.visibleMetrics),
    notify = useStore((s) => s.notify);
  const flow = useReactFlow();
  const [addOpen, setAddOpen] = useState(false),
    [help, setHelp] = useState(false),
    [saved, setSaved] = useState(true),
    [move, setMove] = useState(0);
  const initialized = useRef(false);
  const oldJobs = useRef(new Set<string>());
  usePlayback();
  useEffect(() => {
    useStore.getState().init();
  }, []);
  useEffect(() => {
    if (!loaded || error) return;
    const source = new EventSource("/api/events");
    source.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        useStore.setState({ jobs: data.jobs });
        for (const j of data.jobs) {
          if (j.status === "completed" && !oldJobs.current.has(j.id)) {
            oldJobs.current.add(j.id);
            if (j.kind === "process") {
              useStore.getState().refresh();
              if (j.result?.errors?.length)
                notify(
                  j.result.errors.length +
                    " фото не обработано: " +
                    j.result.errors[0].error,
                );
            }
          }
          if (j.status === "failed" && !oldJobs.current.has(j.id)) {
            oldJobs.current.add(j.id);
            notify(j.message);
          }
        }
      } catch {}
    };
    return () => source.close();
  }, [loaded, error]);
  useEffect(() => {
    if (!loaded || error) return;
    setSaved(false);
    const timeout = setTimeout(() => {
      const s = useStore.getState();
      const ws = {
        version: 1,
        nodes: s.nodes.map(
          ({ id, type, position, style, data, hidden, width, height }) => ({
            id,
            type,
            position,
            style,
            data,
            hidden,
            width,
            height,
          }),
        ),
        edges: s.edges,
        viewport: flow.getViewport(),
        preferences: {
          group: s.group,
          activeId: s.activeId,
          route: s.route,
          heat: s.heat,
          visibleMetrics: s.visibleMetrics,
        },
        saved_at: new Date().toISOString(),
      };
      api("/workspace", { method: "PUT", body: JSON.stringify(ws) })
        .then(() => setSaved(true))
        .catch(() => setSaved(false));
    }, 900);
    return () => clearTimeout(timeout);
  }, [
    nodes,
    edges,
    loaded,
    group,
    activeId,
    route,
    heat,
    visibleMetrics,
    move,
    error,
  ]);
  const init = useCallback(() => {
    if (initialized.current) return;
    initialized.current = true;
    api("/workspace").then((ws) => {
      if (ws?.viewport) flow.setViewport(ws.viewport);
      else setTimeout(() => flow.fitView({ padding: 0.035, maxZoom: 1 }), 100);
    });
  }, [flow]);
  const valid = (c: Edge | Connection) => {
    const output: Record<string, string> = {
      photos: "photos",
      mesh: "mesh",
      landmarks: "landmarks",
      alpha_id: "embedding",
      series: "series",
    };
    if (
      !c.source ||
      !c.target ||
      c.source === c.target ||
      output[c.sourceHandle || ""] !== c.targetHandle
    )
      return false;
    const visited = new Set<string>();
    const reaches = (n: string): boolean => {
      if (n === c.source) return true;
      if (visited.has(n)) return false;
      visited.add(n);
      return edges.filter((e) => e.source === n).some((e) => reaches(e.target));
    };
    return !reaches(c.target);
  };
  const reveal = (id: string) => {
    setAddOpen(false);
    const n = useStore.getState().nodes.find((n) => n.id === id);
    if (n) {
      useStore.setState((s) => ({
        nodes: s.nodes.map((x) => (x.id === id ? { ...x, hidden: false } : x)),
      }));
      setTimeout(
        () => flow.fitView({ nodes: [{ id }], padding: 0.12, duration: 450 }),
        40,
      );
    } else {
      const n = initialNodes.find((n) => n.id === id)!;
      useStore.setState((s) => ({
        nodes: [...s.nodes, { ...n, hidden: false }],
        edges: [
          ...s.edges,
          ...initialEdges.filter(
            (e) =>
              (e.source === id || e.target === id) &&
              !s.edges.some((x) => x.id === e.id) &&
              [...s.nodes.map((n) => n.id), id].includes(e.source) &&
              [...s.nodes.map((n) => n.id), id].includes(e.target),
          ),
        ],
      }));
      setTimeout(
        () => flow.fitView({ nodes: [{ id }], padding: 0.12, duration: 450 }),
        40,
      );
    }
  };
  const add = (type: string, title: string) => {
    setAddOpen(false);
    const id = type + "-" + Date.now(),
      center = flow.screenToFlowPosition({
        x: window.innerWidth * 0.45,
        y: window.innerHeight * 0.28,
      });
    const n: WorkNode = {
      id,
      type,
      position: center,
      style: {
        width: type === "scene" ? 1260 : type === "cluster" ? 570 : 290,
        ...(type === "scene" ? { height: 1010 } : {}),
      },
      data: { title, compact: false },
    };
    const links =
      type === "scene"
        ? [
            {
              id: "edge-" + id,
              source: "recon",
              sourceHandle: "mesh",
              target: id,
              targetHandle: "mesh",
            },
            {
              id: "series-" + id,
              source: "metrics",
              sourceHandle: "series",
              target: id,
              targetHandle: "series",
            },
          ]
        : type === "cluster"
          ? [
              {
                id: "edge-" + id,
                source: "recon",
                sourceHandle: "alpha_id",
                target: id,
                targetHandle: "embedding",
              },
            ]
          : [];
    useStore.setState((s) => ({
      nodes: [...s.nodes, n],
      edges: [
        ...s.edges,
        ...links.map((e) => ({
          ...e,
          style: { stroke: "#a897de", strokeWidth: 1.5 },
        })),
      ],
    }));
  };
  const activeJobs = jobs.filter((j) =>
      ["running", "queued"].includes(j.status),
    ),
    ready = photos.filter((p) => p.status === "ready").length,
    hasDemo = photos
      .filter((p) => group === "__all" || p.group === group)
      .some((p) => p.demo);
  if (!loaded)
    return (
      <div className="startup">
        <div className="brand">
          ATLAS<span>FACE WORKBENCH</span>
        </div>
        <LoaderCircle className="spin" size={22} />
        <p>Загружаем рабочее поле и кэш геометрии…</p>
      </div>
    );
  if (error)
    return (
      <div className="startup">
        <AlertCircle size={28} />
        <h2>Бэкенд недоступен</h2>
        <p>{error}</p>
        <code>python -m uvicorn server.app:app --host 0.0.0.0 --port 8000</code>
        <button className="primary" onClick={() => location.reload()}>
          Повторить
        </button>
      </div>
    );
  return (
    <main className="app">
      <header className="app-header">
        <div className="brand">
          <span className="brand-mark">
            <i />
            <i />
            <i />
          </span>
          ATLAS<span className="brand-caption">FACE WORKBENCH</span>
        </div>
        <div className="header-divider" />
        <div className="project-name">
          <Shapes size={15} />
          <span>Лаборатория изменений</span>
          <ChevronDown size={12} />
        </div>
        <span className="project-tag">WORKSPACE 01</span>
        <div className="header-tools">
          <div className="relative">
            <button
              className={"secondary add-node " + (addOpen ? "active" : "")}
              onClick={() => setAddOpen(!addOpen)}
            >
              <Plus size={14} /> Нода <ChevronDown size={12} />
            </button>
            {addOpen && (
              <div className="add-menu">
                <div className="eyebrow">ДОБАВИТЬ НА КАНВАС</div>
                <button onClick={() => reveal("source")}>
                  <Images size={16} />
                  <span>
                    Фото и серии<small>Источник данных</small>
                  </span>
                </button>
                <button onClick={() => add("scene", "3D-сцена")}>
                  <Focus size={16} />
                  <span>
                    3D-сцена + таймлайн<small>Меш, карта и морфинг</small>
                  </span>
                </button>
                <button onClick={() => add("cluster", "Облако α_id")}>
                  <ScatterChart size={16} />
                  <span>
                    Облако эмбеддингов<small>PCA, UMAP, t-SNE</small>
                  </span>
                </button>
                <button onClick={() => reveal("poses")}>
                  <Compass size={16} />
                  <span>
                    Пять ракурсов<small>Углы и профили</small>
                  </span>
                </button>
                <button onClick={() => reveal("registry")}>
                  <Activity size={16} />
                  <span>
                    Метрики и пороги<small>Python + YAML</small>
                  </span>
                </button>
                <div className="menu-divider" />
                {["MediaPipe", "FAN", "AdaFace"].map((t) => (
                  <button key={t} onClick={() => add("pending", t)}>
                    <Lock size={14} />
                    <span>
                      {t}
                      <small>Следующий этап · не установлена</small>
                    </span>
                  </button>
                ))}
              </div>
            )}
          </div>
          <button
            className="header-text-button"
            onClick={() => reveal("poses")}
          >
            <Compass size={14} /> Ракурсы
          </button>
          <button
            className="header-text-button"
            onClick={() => reveal("registry")}
          >
            <Activity size={14} /> Метрики
          </button>
          <div className="header-divider" />
          <span className="cpu-chip">
            <span className="status-dot" />
            <Cpu size={12} /> CPU · 2
          </span>
          <span className="save-indicator">
            <Check size={13} />
            {saved ? "Сохранено" : "Сохраняется…"}
          </span>
          <button
            className="icon-btn"
            title="Управление"
            onClick={() => setHelp(!help)}
          >
            <HelpCircle size={17} />
          </button>
        </div>
      </header>
      <div className="canvas-wrap">
        <ReactFlow
          nodes={nodes}
          edges={edges}
          nodeTypes={nodeTypes}
          onNodesChange={onNodesChange}
          onEdgesChange={onEdgesChange}
          onConnect={onConnect}
          isValidConnection={valid}
          onInit={init}
          onMoveEnd={() => setMove((x) => x + 1)}
          minZoom={0.18}
          maxZoom={2}
          onlyRenderVisibleElements
          deleteKeyCode={["Backspace", "Delete"]}
          selectionOnDrag
          panOnDrag={[1, 2]}
          panActivationKeyCode="Space"
          selectionKeyCode="Shift"
          multiSelectionKeyCode={["Meta", "Control"]}
          attributionPosition="top-right"
          defaultEdgeOptions={{ type: "default" }}
          fitViewOptions={{ padding: 0.03 }}
          colorMode="dark"
        >
          <Background
            variant={BackgroundVariant.Dots}
            gap={22}
            size={1}
            color="#2c3a47"
            bgColor="#10161e"
          />
          <Controls showInteractive={false} />
          <MiniMap
            pannable
            zoomable
            bgColor="#101820"
            nodeColor={(n) =>
              n.type === "scene"
                ? "#4c887e"
                : n.type === "cluster"
                  ? "#79699a"
                  : "#354b5b"
            }
            maskColor="rgba(7,12,17,.7)"
          />
          <Panel position="top-left">
            <div className="canvas-breadcrumb">
              <span>01</span> РАБОЧЕЕ ПОЛЕ <i /> бесконечный канвас
            </div>
          </Panel>
          <Panel position="bottom-center">
            <button
              className="canvas-fit"
              onClick={() => flow.fitView({ padding: 0.04, duration: 450 })}
            >
              <Maximize size={13} /> Показать все ноды
            </button>
          </Panel>
        </ReactFlow>
        {help && (
          <div className="help-panel">
            <div className="flex between">
              <strong>Рабочее поле</strong>
              <button className="icon-btn" onClick={() => setHelp(false)}>
                <X size={14} />
              </button>
            </div>
            <p>
              <kbd>Space</kbd> + мышь — двигать канвас
            </p>
            <p>Колесо — масштаб. За заголовок — перемещение ноды.</p>
            <p>Потяните от разъёма, чтобы соединить совместимые данные.</p>
            <p>
              <kbd>Ctrl/⌘</kbd> + фото — маршрут до 10 кадров.
            </p>
            <p>
              <kbd>Shift</kbd> + фото — диапазон. Двойной клик — дата и углы.
            </p>
            <p>Свернуть ≠ отключить. Выключенный плагин сохраняет кэш.</p>
            <button
              className="text-button"
              onClick={() => {
                useStore.setState({
                  nodes: initialNodes.map((n) => ({ ...n })),
                  edges: initialEdges,
                });
                setHelp(false);
                setTimeout(
                  () => flow.fitView({ padding: 0.035, duration: 400 }),
                  100,
                );
              }}
            >
              <Undo2 size={12} /> Сбросить только раскладку
            </button>
          </div>
        )}
        {toast && (
          <div role="status" className="toast">
            <span>{toast}</span>
            <button
              className="icon-btn"
              onClick={() => useStore.setState({ toast: null })}
            >
              <X size={13} />
            </button>
          </div>
        )}
        <PhotoEditor />
      </div>
      <footer className="app-status">
        <span>
          <span className="status-dot" /> {ready} фото в кэше <b>·</b>{" "}
          {models.find((m) => m.id === "3ddfa_v3")?.available
            ? models.find((m) => m.id === "3ddfa_v3")?.enabled
              ? "3DDFA_V3 готова"
              : "3DDFA_V3 выключена"
            : "Нет весов · доступен кэш"}
          {activeJobs.length > 0 && (
            <span className="status-job">
              <LoaderCircle className="spin" size={10} />{" "}
              {activeJobs[0].message}
            </span>
          )}
        </span>
        {hasDemo ? (
          <span className="demo-disclaimer">
            Демо: варианты одного синтетического фото · даты условные
          </span>
        ) : (
          <span className="muted">
            Обработка в среде проекта · без внешнего inference API
          </span>
        )}
        <span className="status-right">
          seed 42 <b>·</b> workspace.json
        </span>
      </footer>
    </main>
  );
}
export default function App() {
  return (
    <ReactFlowProvider>
      <Workbench />
    </ReactFlowProvider>
  );
}
