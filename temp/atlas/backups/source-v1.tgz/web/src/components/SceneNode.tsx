import { memo, useState } from "react";
import { NodeResizer, useReactFlow, type NodeProps } from "@xyflow/react";
import { Focus, PanelRightClose, PanelRightOpen, Layers3 } from "lucide-react";
import { useStore, type WorkNode, poseLabels } from "../store";
import { Viewer, HeatControls } from "./Viewer";
import { Timeline } from "./Timeline";
import { NodeHead, Port, Empty } from "./ui";
import type { HeatStats } from "../heat";
export const SceneNode = memo(function SceneNode({
  id,
  data,
  selected,
}: NodeProps<WorkNode>) {
  const [stats, setStats] = useState<HeatStats | null>(null);
  const open = useStore((s) => s.settingsOpen),
    set = useStore((s) => s.set),
    patch = useStore((s) => s.patchNode),
    active = useStore((s) => s.photos.find((p) => p.id === s.activeId)),
    models = useStore((s) => s.models);
  const rf = useReactFlow();
  return (
    <div
      className={"node-card scene-node " + (data.collapsed ? "collapsed" : "")}
    >
      <NodeResizer
        isVisible={selected && !data.collapsed}
        minWidth={900}
        minHeight={800}
        lineStyle={{ borderColor: "#64d7b7", opacity: 0.5 }}
        handleStyle={{
          background: "#64d7b7",
          width: 6,
          height: 6,
          borderRadius: 2,
        }}
      />
      <NodeHead
        id={id}
        title="3D-сцена + таймлайн"
        subtitle={data.collapsed ? "Меш · карта · точки · морфинг" : undefined}
        icon={<Focus size={16} />}
        collapsed={data.collapsed}
        badge={
          <span className="scene-connection">
            <span className="status-dot" />
            {active ? poseLabels[active.pose] : "Ожидание фото"}
          </span>
        }
        onExpand={() =>
          rf.fitView({ nodes: [{ id }], padding: 0.04, duration: 450 })
        }
        onHide={() => patch(id, { previewHidden: !data.previewHidden })}
        hiddenPreview={data.previewHidden}
      >
        <button
          className="icon-btn nodrag"
          title="Панель тепловой карты"
          onClick={() => set({ settingsOpen: !open })}
        >
          {open ? <PanelRightClose size={14} /> : <PanelRightOpen size={14} />}
        </button>
      </NodeHead>
      {!data.collapsed && (
        <>
          <div className="scene-stage">
            {data.previewHidden ? (
              <div className="hidden-scene">
                <Empty
                  title="Превью скрыто"
                  detail="Нода не рендерит 3D. Связи и рассчитанные данные сохранены."
                >
                  <button
                    className="secondary small"
                    onClick={() => patch(id, { previewHidden: false })}
                  >
                    Показать модель
                  </button>
                </Empty>
              </div>
            ) : (
              <Viewer sceneId={id} onStats={setStats} />
            )}{" "}
            {open && <HeatControls stats={stats} />}
          </div>
          {models.find((m) => m.id === "3ddfa_v3")?.enabled === false && (
            <div className="cached-note">
              Плагин выключен · показаны сохранённые результаты
            </div>
          )}
          <Timeline sceneId={id} stats={stats} />
        </>
      )}
      <Port
        id="mesh"
        type="target"
        color="#b29bea"
        top={data.collapsed ? "35%" : 150}
      />
      <Port
        id="series"
        type="target"
        color="#61ceb1"
        top={data.collapsed ? "70%" : "84%"}
      />
    </div>
  );
});
