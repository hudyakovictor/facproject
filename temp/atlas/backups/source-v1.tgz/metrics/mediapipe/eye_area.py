from server.registry import metric
from metrics.common import polygon_area
import numpy as np


@metric(
    "mp_eye_area",
    "Площадь глаз / IOD²",
    model="mediapipe",
    unit="IOD²",
    inputs=("mp478",),
)
def compute(ctx):
    p = ctx["mp478"]
    left = [33, 160, 158, 133, 153, 144]
    right = [362, 385, 387, 263, 373, 380]
    iod = np.linalg.norm(p[left].mean(0) - p[right].mean(0))
    return (polygon_area(p[left, :2]) + polygon_area(p[right, :2])) / (
        2 * max(iod**2, 1e-12)
    )
